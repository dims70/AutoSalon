﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;

namespace AutoSalon
{
    //Форма непосредственного интерфейса.
    public partial class InterfaceForm : Form
    {
        #region Обьявления
        public delegate void RefCBox();
        public delegate void RefABox();
        public RefABox delRefAbox;
        public RefCBox del;
        MainForm form;
        Connection conn = new Connection();
        public List<int> list;
        public List<int> listDistCode;
        public List<int> IdSupplier;
        public AutoClass linkAutoExample;
        #endregion
        //Инициализация формы
        public InterfaceForm(MainForm mainForm)
        {
            InitializeComponent();
            form = mainForm;
            label1.Text = mainForm.send.login;
            GC();
            FillAllDataGridView();
        }
        /// <summary>
        /// Заполнение всех элементов DataGridView при инициализации формы.
        /// </summary>
        private void FillAllDataGridView()
        {
            dataListOrder.DataSource = FillDataGrid("СписокЗаказов");
            dataSuppView.DataSource = FillDataGrid("Поставки");
            dataListSupp.DataSource = FillDataGrid("Поставщики");
            dataListDist.DataSource = FillDataGrid("Перегонщики");
            dataListAuto.DataSource = FillDataGrid("Автомобили");
            dataListContract.DataSource = FillDataGrid("ДоговорПоставщика");
        }

        /// <summary>
        /// Заполнение автомобилями и перегонщиков  раскрывающего списка
        /// </summary>
        /// <param name="queryAuto">Запрос к списку автомобилей</param>
        /// <param name="queryDist">Запрос к списку поставщиков</param>
        //Заполнение раскрывабщего списка автомобилей и поставщиков
        public void FillComboAuto(string queryAuto, string queryDist)
        {
            var cmd = new SqlCommand(queryAuto, conn.SqlConnection);
            SqlDataReader reader = cmd.ExecuteReader();
            string temp;
            list = new List<int>();
            while (reader.Read())
            {
                temp = $"{(string)reader[1]} {(string)reader[2]}";
                ComboAutoBox.Items.Add(temp);
                SuppAutoBox.Items.Add(temp);
                list.Add((int)reader[0]);
                AutoClass.AutoCollection.Add(new AutoClass() { _stamp = reader.GetString(1), _model = reader.GetString(2) });
            }
            reader.Close();
            ComboAutoBox.DataSource = AutoClass.AutoCollection;
            cmd.CommandText = queryDist;
            reader = cmd.ExecuteReader();
            listDistCode = new List<int>();
            while (reader.Read())
            {
                listDistCode.Add((int)reader[0]);
                temp = reader[1] + "";
                ComboDistBox.Items.Add(temp);
            }
            reader.Close();
        }
        /// <summary>
        /// Заполнение для DataGrid
        /// </summary>
        /// <param name="query">Заполнение запросом</param>
        /// <param name="table">Создание таблицы в хранилище</param>
        /// <returns>Возвращаемая таблица</returns>
        public DataTable FillDataGrid(string table)
        {
            var dataSet = new DataSet();
            var dataAdapter = new SqlDataAdapter($"select * from {table}", conn.SqlConnection);
            dataAdapter.Fill(dataSet, table);
            return dataSet.Tables[table];
        }
        //Заполнение стоимости автомобиля в надпись
        private void ComboAutoBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectID = list[ComboAutoBox.SelectedIndex];
            var cmd = new SqlCommand($"select Стоимость from Автомобили where КодАвтомобиля={selectID}", conn.SqlConnection);
            var cost = cmd.ExecuteScalar();
            label15.Text = cost + "";
        }
        //Кнопка перехода на формы создания заказа
        private void btnOrder_Click(object sender, EventArgs e)
        {
            LeftTabControl.SelectTab(LeftPage1);
            RightTabControl.SelectTab(RightPage1);
        }
        /// <summary>
        /// Заполнение поставщиков
        /// </summary>
        public void FillComboSupplier()
        {
            SuppPostBox.Items.Add("новый...");
            var cmd = new SqlCommand("select * from Поставщики", conn.SqlConnection);
            SqlDataReader reader = cmd.ExecuteReader();
            IdSupplier = new List<int>();
            while (reader.Read())
            {
                IdSupplier.Add((int)reader[0]);
                SuppPostBox.Items.Add(reader[1]);
            }
            reader.Close();
        }
        //Добавление нового вида автомобиля при нажатии на "новый..."
        private void SuppAutoBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SuppAutoBox.SelectedItem.ToString() == "новый...")
            {
                var createAuto = new Auto(this);
                createAuto.ShowDialog();
            }

        }
        /// <summary>
        /// Автообновление бокса авто
        /// </summary>
        private void AutoBoxRefresh()
        {
            SuppAutoBox.Items.Clear();
            SuppAutoBox.Items.Add("новый...");
            var cmd = new SqlCommand("select * from Автомобили", conn.SqlConnection);
            SqlDataReader reader = cmd.ExecuteReader();
            string temp;
            list = new List<int>();
            while (reader.Read())
            {
                temp = $"{(string)reader[1]} {(string)reader[2]}";
                SuppAutoBox.Items.Add(temp);
                list.Add((int)reader[0]);
            }
            reader.Close();
        }
        // Вызов окна добавления поставщика
        private void SuppPostBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SuppPostBox.SelectedItem.ToString() == "новый...")
            {
                var createSupp = new AddSupplier(this);
                createSupp.ShowDialog();
            }
        }

        private void btnCreateOrder_Click(object sender, EventArgs e)
        {
            var rand = new Random();
            int numdognext = rand.Next(100000, 999999);
            var services = new Services();
            try
            {
                if (FIOBox.Text != "" && AdrBox.Text != "" && PhoneBox.Text != "" && PassportBox.Text != "")
                {
                    services.CreateOrder(form.send.id, numdognext.ToString(), FIOBox.Text, AdrBox.Text, PhoneBox.Text, PassportBox.Text, list[ComboAutoBox.SelectedIndex], listDistCode[ComboDistBox.SelectedIndex], Convert.ToDecimal(label15.Text));
                    MessageBox.Show("Заказ успешно оформлен.");
                    dataListOrder.DataGridRefresh("СписокЗаказов");
                }
                else
                {
                    MessageBox.Show("Проверьте поля ввода и повторите попытку.");
                }

            }
            catch
            {

                MessageBox.Show("Проверьте поля ввода и повторите попытку.");
            }


        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            LeftTabControl.SelectTab(LeftPage1);
            RightTabControl.SelectTab(RightPage1);
            FillAllDataGridView();
        }

        private void btnSupply_Click(object sender, EventArgs e)
        {
            LeftTabControl.SelectTab(LeftPage2);
            RightTabControl.SelectTab(RightPage2);
            FillAllDataGridView();
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {

            LeftTabControl.SelectTab(LeftPage3);
            RightTabControl.SelectTab(RightPage3);
            FillAllDataGridView();
            BoxNumberContractSupplier.FillComboBox("НомерДоговора", "ДоговорПоставщика");
        }

        private void btnDist_Click(object sender, EventArgs e)
        {
            LeftTabControl.SelectTab(LeftPage4);
            RightTabControl.SelectTab(RightPage4);
            FillAllDataGridView();
        }

        private void btnAuto_Click(object sender, EventArgs e)
        {
            LeftTabControl.SelectTab(LeftPage5);
            RightTabControl.SelectTab(RightPage5);
            FillAllDataGridView();
        }

        private void btnCreateSupp_Click(object sender, EventArgs e)
        {
            var services = new Services();
            try
            {
                services.CreateSupply(
                    dateSupply.Value, 
                    list[SuppAutoBox.SelectedIndex - 1], 
                    int.Parse(NumberBoxSupp.Text),
                    decimal.Parse(SummSupp.Text), 
                    IdSupplier[SuppPostBox.SelectedIndex - 1]);
            }
            catch
            {
                MessageBox.Show("Заполните все поля");
            }
            MessageBox.Show("Заказ успешно оформлен.");
            dataSuppView.DataGridRefresh("Поставки");
        }

        private void NumberBoxSupp_TextChanged(object sender, EventArgs e)
        {
            try
            {
                var cmd = new SqlCommand($"select Стоимость from Автомобили where КодАвтомобиля={list[SuppAutoBox.SelectedIndex - 1]}", conn.SqlConnection);

                decimal cost = (decimal)cmd.ExecuteScalar();
                if (int.TryParse(NumberBoxSupp.Text, out int tempresult))
                {
                    SummSupp.Text = (cost * tempresult).ToString();
                }
                else
                {
                    MessageBox.Show("Введите число.");
                }
            }
            catch
            {
                MessageBox.Show("Выберите автомобиль.");
            }

        }

        private void btnListContract_Click(object sender, EventArgs e)
        {
            LeftTabControl.SelectTab(LeftPage6);
            RightTabControl.SelectTab(RightPage6);
            FillAllDataGridView();
        }

        private void btnCreateSupplier_Click(object sender, EventArgs e)
        {
            var services = new Services();
            services.AddSupplier(textBoxNameSupplier.Text, textBoxAdressSupplier.Text, textBoxPhoneSupplier.Text, BoxNumberContractSupplier.SelectedItem.ToString());
            MessageBox.Show("Поставщик внесен в список.");
            dataListSupp.DataGridRefresh("Поставщики");
        }
        //Метод при вызывающий при инициализации
        private void GC()
        {

            timer1.Start();
            label13.Text = DateTime.Today.ToShortDateString() + "";
            conn.ConnectionOpen();
            FillComboAuto("select * from Автомобили", "select * from Перегонщики");
            FillComboSupplier();
            del = AutoBoxRefresh;
            delRefAbox += () => { SuppPostBox.Items.Clear(); };
            delRefAbox += FillComboSupplier;
            LeftTabControl.ItemSize = new System.Drawing.Size(0, 1);
            RightTabControl.ItemSize = new System.Drawing.Size(0, 1);
        }
        #region Закрытие формы и таймер на дату-время
        private void InterfaceForm_FormClosed(object sender, FormClosedEventArgs e) => form.Show();
        private void timer1_Tick(object sender, EventArgs e) => label3.Text = DateTime.Now + "";
        #endregion

        private void btnCreateDist_Click(object sender, EventArgs e)
        {
            var services = new Services();
            if (decimal.TryParse(CostForKm.Text, out decimal result))
            {
                services.AddDist(NameDist.Text, textBoxPhoneDist.Text, BoxTypeDist.SelectedItem.ToString(), result);
                dataListDist.DataGridRefresh("Перегонщики");
            }
            else
            {
                MessageBox.Show("Введите число.");
            }
        }

        private void btnSaveAuto_Click(object sender, EventArgs e)
        {
            var services = new Services();
            if (decimal.TryParse(textBoxCost.Text, out decimal cost))
            {
                services.AddAuto(
                    textBoxStamp.Text,
                    textBoxModel.Text,
                    textBoxCLass.Text,
                    textBoxTBuild.Text,
                    textBoxTBody.Text,
                    textBoxColor.Text,
                    textBoxCYear.Text,
                    textBoxComplect.Text, 
                    cost);
                MessageBox.Show("Автомобиль добавлен в список.");
                dataListAuto.DataGridRefresh("Автомобили");
            }
            else MessageBox.Show("Стоимость должна быть числовым значением.");
        }

        private void btnCreateContract_Click(object sender, EventArgs e)
        {
            var services = new Services();
            services.AddContract(textBoxContract.Text,dateCreateContract.Value,dateExpiresContract.Value);
            MessageBox.Show("Договор создан.");
            dataListContract.DataGridRefresh("ДоговорПоставщика");
        }
    }

}


