﻿namespace AutoSalon
{   /// <summary>
    /// Класс авторизированного пользователя
    /// </summary>
   public class SignedUser
    {
        public int id { get;private set; }
        public string login { get; private set; }
        public SignedUser(int Id, string Login)
        {
            id = Id;
            login = Login;
        }

    }
}
