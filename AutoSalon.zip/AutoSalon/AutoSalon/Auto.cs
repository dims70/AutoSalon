﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AutoSalon
{
    public partial class Auto : Form
    {
        #region Обьявления
        InterfaceForm form;
        #endregion
        //Инициализация формы
        public Auto(InterfaceForm Iform)
        {
            InitializeComponent();
            form = Iform;
        }
        //Кнопка сохранения нового авто
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!decimal.TryParse(textBoxCost.Text, out decimal Cost))
                {
                    MessageBox.Show("Поля должны быть заполнены, а цена должна быть числовым значением.");
                }
                else
                { 
                var autoexample = new AutoClass(textBoxStamp.Text, textBoxModel.Text, textBoxCLass.Text, textBoxTBuild.Text, textBoxTBody.Text, textBoxColor.Text, textBoxCYear.Text, textBoxComplect.Text, Cost);
                form.linkAutoExample = autoexample;
                var conn = new Connection();
                conn.ConnectionOpen();
                var query = $"insert into Автомобили values (@marka,@model,@category,@typeBuild,@typeBody,@color,@createYear,@complect, @cost); set @id = SCOPE_IDENTITY()";
                var cmd = new SqlCommand(query, conn.SqlConnection);
                cmd.Parameters.AddRange(new SqlParameter[] {
                    new SqlParameter("@marka", autoexample._stamp),
                    new SqlParameter("@model", autoexample._model),
                    new SqlParameter("@category", autoexample._category),
                    new SqlParameter("@typeBuild", autoexample._typeBuild),
                    new SqlParameter("@typeBody", autoexample._typeBody),
                    new SqlParameter("@color", autoexample._color),
                    new SqlParameter("@createYear", autoexample._createYear),
                    new SqlParameter("@complect", autoexample._complect),
                    new SqlParameter("@cost", autoexample._cost) });
                    SqlParameter id = new SqlParameter("@id", System.Data.SqlDbType.Int)
                    {
                        Direction = System.Data.ParameterDirection.Output
                    };
                cmd.Parameters.Add(id);
                cmd.ExecuteNonQuery();
                form.list.Add((int)id.Value);
                MessageBox.Show("Автомобиль внесен в реестр.");
                AutoClass.AutoCollection.Add(autoexample);
                Close();
                form.del();
                }
            }
            catch
            {
                MessageBox.Show("Введите все значения полей.");
            }

        }
    }
}
