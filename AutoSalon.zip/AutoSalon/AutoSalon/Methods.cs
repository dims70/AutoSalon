﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AutoSalon
{
  public static class Methods
    {
       static Connection conn = new Connection();
        /// <summary>
        /// Обновление элемента DataGridView
        /// </summary>
        /// <param name="table">Таблица из запроса</param>
       public static void DataGridRefresh(this DataGridView dataGrid, string table)
        {
            conn.ConnectionOpen();
            var dataSet = new DataSet();
            dataSet.Clear();
            var dataAdapter = new SqlDataAdapter($"select * from {table}", conn.SqlConnection);
            dataAdapter.Fill(dataSet, table);
            dataGrid.DataSource= dataSet.Tables[table];
            conn.ConnectionClose();
        }
        /// <summary>
        /// Заполнение Combobox-a одним столбцом из запроса
        /// </summary>
        /// <param name="field">Столбец из запроса</param>
        /// <param name="table">Таблица из запроса</param>
        public static void FillComboBox(this ComboBox comboBox, string field, string table)
        {
            conn.ConnectionOpen();
            var cmd = new SqlCommand($"select {field} from {table}", conn.SqlConnection);
            var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
               comboBox.Items.Add(reader[0]);
            }
            reader.Close();
            conn.ConnectionClose();
        }
    }
}
