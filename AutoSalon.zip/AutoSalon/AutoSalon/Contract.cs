﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AutoSalon
{
    public partial class Contract : Form
    {
        #region Обьявления
        AddSupplier ASForm;
        public Contr ContractExample;
        Connection conn = new Connection();
        #endregion
        public Contract(AddSupplier AS)
        {
            InitializeComponent();
            ASForm = AS;
        }
        //Кнопка сохранения данных договора в БД.
        private void btnCreateContract_Click(object sender, EventArgs e)
        {
            var contract = new Contr(textBoxContract.Text,dateCreateContract.Value.ToShortDateString().ToString(),dateExpiresContract.Value.ToShortDateString().ToString());
            ContractExample = contract;
            var cmd = new SqlCommand($"insert into ДоговорПоставщика values (@cont,@dc,@de)",conn.SqlConnection);
            cmd.Parameters.AddRange(new SqlParameter[] 
            {
                new SqlParameter("@cont",contract.NumberContract),
                new SqlParameter("@dc", contract.dateCreate),
                new SqlParameter("@de",contract.dateExpires)
            });
            cmd.ExecuteNonQuery();
            MessageBox.Show("Договор создан.");
            Close();
        }
        //Действия по закрытию формы
        private void Contract_FormClosed(object sender, FormClosedEventArgs e)
        { 
            conn.ConnectionClose();
            ASForm.del();
            
        }
        //Открытие подключения при появлении формы внесения данных в БД.
        private void Contract_Load(object sender, EventArgs e) => conn.ConnectionOpen();
    }
}
