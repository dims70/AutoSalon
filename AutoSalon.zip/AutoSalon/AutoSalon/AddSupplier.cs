﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AutoSalon
{
    public partial class AddSupplier : Form
    {   
        #region Обьявления
        Connection conn = new Connection();
        InterfaceForm Iform;
        Contract Contract;
        public delegate void FillBoxContr();
        public FillBoxContr del;
        #endregion
        //Действия при инициализации формы
        public AddSupplier(InterfaceForm form)
        {
            InitializeComponent();
            Iform = form;
            conn.ConnectionOpen();
            del = FillNumContr;
            Contract = new Contract(this);
            
        }
        //Сохраняет созданного поставщика
        private void btnSave_Click(object sender, EventArgs e)
        {   if(textBoxName.Text!=""&& textBoxPhone.Text!="" && textBoxAdress.Text!=""&& textBoxNumDog.Text!="")
            { 
            var supplier = new Supplier(textBoxName.Text, textBoxPhone.Text,textBoxAdress.Text,Convert.ToInt32(textBoxNumDog.Text));
            var cmd = new SqlCommand("insert into Поставщики values(@name,@phone,@adress,@numContr); set @id = SCOPE_IDENTITY()", conn.SqlConnection);
            cmd.Parameters.AddRange(new SqlParameter[]
            {
                new SqlParameter("@name",supplier._name),
                new SqlParameter("@phone",supplier._phone),
                new SqlParameter("@adress",supplier._adress),
                new SqlParameter("@numContr",supplier._numberDog),
                
            }
                );
                SqlParameter id = new SqlParameter("@id", System.Data.SqlDbType.Int)
                {
                    Direction = System.Data.ParameterDirection.Output
                };
                cmd.Parameters.Add(id);
            cmd.ExecuteNonQuery();
                MessageBox.Show("Поставщик создан.");
                Close();
                Iform.delRefAbox();
                Iform.IdSupplier.Add((int)id.Value);
            }
        else
            {
                MessageBox.Show("Заполните все поля");
            }
        }
        //Открывает форму создания договора поставщика
        private void btnCreateCont_Click(object sender, EventArgs e)
        {
            Contract.ShowDialog();
        }
        //Разрыв соединения при закрытии формы
        private void AddSupplier_FormClosed(object sender, FormClosedEventArgs e) => conn.ConnectionClose();
        /// <summary> 
        /// Метод вызывающий в делегате после создания нового договора
        /// </summary>
        public void FillNumContr()
            
        {   if(Contract.ContractExample!=null)
            {
                textBoxNumDog.Text = Contract.ContractExample.NumberContract;
                textBoxName.Enabled = true;
                textBoxPhone.Enabled = true;
                textBoxAdress.Enabled = true;
            }
        }

    }
}
