﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AutoSalon
{   /// <summary>
    /// Класс реализующий непосредственную работу.
    /// </summary>
    class Services : IServices
    {
       static Connection conn = new Connection();
        /// <summary>
        /// Добавление автомобиля в базу
        /// </summary>
        public void AddAuto(
            string stamp,
            string model,
            string type,
            string typeBuild,
            string typeBody,
            string color,
            string yearBorn,
            string complect,
            decimal cost)
        {
            var rand = new Random(DateTime.Now.Millisecond);
            conn.ConnectionOpen();
            var cmd = new SqlCommand("insert into Автомобили values (@КодАвтомобиля,@marka,@model,@category,@typeBuild,@typeBody,@color,@createYear,@complect, @cost)", conn.SqlConnection);
            cmd.Parameters.AddRange(new SqlParameter[] {
                    new SqlParameter("@КодАвтомобиля", rand.Next(1000000,9999999)),
                    new SqlParameter("@marka", stamp),
                    new SqlParameter("@model", model),
                    new SqlParameter("@category", type),
                    new SqlParameter("@typeBuild", typeBuild),
                    new SqlParameter("@typeBody", typeBody),
                    new SqlParameter("@color", color),
                    new SqlParameter("@createYear", yearBorn),
                    new SqlParameter("@complect", complect),
                    new SqlParameter("@cost", cost) });
            cmd.ExecuteNonQuery();
            conn.ConnectionClose();
        }
        /// <summary>
        /// Добавление договора на поставщика
        /// </summary>
        public void AddContract(string numContract, DateTime dCreate, DateTime dExpires)
        {
            conn.ConnectionOpen();
            try
            {
                var cmd = new SqlCommand("insert into ДоговорПоставщика values(@НомерДоговора,@ДатаСоздания,@ДатаИстечения)", conn.SqlConnection);
                cmd.Parameters.AddRange(new SqlParameter[]
                {   new SqlParameter("@НомерДоговора",numContract),
                    new SqlParameter("@ДатаСоздания",dCreate),
                    new SqlParameter("@ДатаИстечения",dExpires),
                }
                    );
                cmd.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Заполните поля верно.");
            }
            conn.ConnectionClose();
        }

        /// <summary>
        /// Добавление перегонщика
        /// </summary>
        /// <param name="Name"></param>
        /// <param name="PhoneNumm"></param>
        /// <param name="TypeDist"></param>
        /// <param name="cost"></param>
        public void AddDist(
            string Name,
            string PhoneNumm, 
            string TypeDist,
            decimal cost)
        {
            var rand = new Random(DateTime.Now.Millisecond);
            conn.ConnectionOpen();
            try
            {
                var cmd = new SqlCommand("insert into Перегонщики values(@КодПерегонщика,@Название,@НомерТелефона,@Тип,@ЦенаЗаКм)", conn.SqlConnection);
                cmd.Parameters.AddRange(new SqlParameter[]
                {   new SqlParameter("@Название",Name),
                    new SqlParameter("@Тип",TypeDist),
                    new SqlParameter("@НомерТелефона",PhoneNumm),
                    new SqlParameter("@ЦенаЗаКм",cost),
                    new SqlParameter("@КодПерегонщика",rand.Next(1000000,9999999)),
                }
                    );
                cmd.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Заполните поля верно.");
            }
            conn.ConnectionClose();
        }
        /// <summary>
        /// Добавление поставщика
        /// </summary>
        /// <param name="Name"></param>
        /// <param name="Adress"></param>
        /// <param name="PhoneNum"></param>
        /// <param name="NumberContract"></param>
        public void AddSupplier(string Name,
            string Adress, 
            string PhoneNum,
            string NumberContract)
        { var rand = new Random(DateTime.Now.Millisecond);
            conn.ConnectionOpen();
            try
            {
                var cmd = new SqlCommand("insert into Поставщики values(@КодПоставщика,@Название,@НомерТелефона,@Адрес,@НомерДоговора)", conn.SqlConnection);
                cmd.Parameters.AddRange(new SqlParameter[]
                {   new SqlParameter("@Название",Name),
                    new SqlParameter("@Адрес",Adress),
                    new SqlParameter("@НомерТелефона",PhoneNum),
                    new SqlParameter("@НомерДоговора",NumberContract),
                    new SqlParameter("@КодПоставщика",rand.Next(100000,999999)),
                }
                    );
                cmd.ExecuteNonQuery();
        }
            catch
            {
                MessageBox.Show("Заполните поля верно.");
            }
    conn.ConnectionClose();
        }
        /// <summary>
        /// Создание заказа
        /// </summary>
        /// <param name="idManager"></param>
        /// <param name="FIO_Client"></param>
        /// <param name="Adr_Client"></param>
        /// <param name="PhoneNumber"></param>
        /// <param name="Passport"></param>
        /// <param name="dateToday"></param>
        public void CreateOrder(
            int idManager,
            string numcontact,
            string FIO_Client,
            string Adr_Client,
            string PhoneNumber, 
            string Passport,
            int idCar,
            int idDist,
            decimal endCost)
        {
            conn.ConnectionOpen();
            try
            {
                var cmd = new SqlCommand("insert into СписокЗаказов values(@idmanager,@numcontr,@fioclient,@adrclient,@numphone,@passport,@datetoday,@idcar,@iddist,@endcost)",conn.SqlConnection);
                cmd.Parameters.AddRange(new SqlParameter[]
                {   new SqlParameter("@numcontr",numcontact),
                    new SqlParameter("@idmanager",idManager),
                    new SqlParameter("@fioclient",FIO_Client),
                    new SqlParameter("@adrclient",Adr_Client),
                    new SqlParameter("@numphone",PhoneNumber),
                    new SqlParameter("@passport",Passport),
                    new SqlParameter("@datetoday", DateTime.Today.ToShortDateString()),
                    new SqlParameter("@idcar",idCar),
                    new SqlParameter("@iddist",idDist),
                    new SqlParameter("@endcost",endCost),
                }
                    );
                cmd.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Заполните поля верно.");
            }
            conn.ConnectionClose();
        }
        /// <summary>
        /// Создание поставки
        /// </summary>
        /// <param name="date"></param>
        /// <param name="CodeAuto"></param>
        /// <param name="number"></param>
        /// <param name="FinSumm"></param>
        /// <param name="idSupplier"></param>
        public void CreateSupply(
            DateTime date,
            int CodeAuto, 
            int number, 
            decimal FinSumm,
            int idSupplier)
        {
            conn.ConnectionOpen();
            try
            {
                var cmd = new SqlCommand($"insert into Поставки(ДатаПоставки,КодАвтомобиля,Количество,ЦенаПартии,КодПоставщика) values(@date,@autoid,@number,@summ,@supplierid)", conn.SqlConnection);
                cmd.Parameters.AddRange(new SqlParameter[] {
                    new SqlParameter("@date",date),
                    new SqlParameter("@autoid",CodeAuto),
                    new SqlParameter("@number",number),
                    new SqlParameter("@summ",FinSumm),
                    new SqlParameter("@supplierid",idSupplier), 
                }
                    );
                cmd.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Заполните поля верно.");
            }
            conn.ConnectionClose();
        }
    }
}
