﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AutoSalon
{
    public partial class AdminPanel : Form
    {
        Connection conn = new Connection();
        SqlDataAdapter DA = new SqlDataAdapter();
        SqlDataAdapter DA1 = new SqlDataAdapter();
        DataSet DS = new DataSet();
        public AdminPanel()
        {
            conn.ConnectionOpen();
            InitializeComponent();
            DataSet_DataGridFill();
            conn.ConnectionClose();
        }

        private void btnSaveData_Click(object sender, EventArgs e)
        {
            
            var cmdBuilder = new SqlCommandBuilder(DA);
            var cmdBuilder1 = new SqlCommandBuilder(DA1);
            try
            {
                DA.Update(DS, "Менеджеры");
            DA1.Update(DS, "Авторизация");
            MessageBox.Show("Изменения сохранены.");
        }
            catch
            {
                MessageBox.Show("Заполните поля в двух таблицах.");
            }

}
        private void DataSet_DataGridFill()
        {
            var dataSet = new DataSet();
            DS = dataSet;
            var dataAdapter = new SqlDataAdapter("select * from Менеджеры", conn.SqlConnection);
            DA = dataAdapter;
            dataAdapter.Fill(dataSet, "Менеджеры");
            var dataAdapter1 = new SqlDataAdapter("select * from Авторизация", conn.SqlConnection);
            DA1 = dataAdapter1;
            dataAdapter1.Fill(dataSet, "Авторизация");
            dataManager.DataSource = dataSet.Tables["Менеджеры"];
            dataAuthMenager.DataSource = dataSet.Tables["Авторизация"];
        }

        private void dataAuthMenager_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            conn.ConnectionOpen();
            if (e.ColumnIndex==0)
            {
               string res = MessageBox.Show("Вы точно хотите удалить эту строку?","Подтверждение",MessageBoxButtons.YesNo,MessageBoxIcon.Question).ToString();
               if(res=="Yes")
               {
                    var cmd = new SqlCommand($"delete from Авторизация where idМенеджера='{dataAuthMenager.Rows[e.RowIndex].Cells[1].Value}'",conn.SqlConnection);
                    cmd.ExecuteNonQuery();
               }
            }
            dataAuthMenager.DataGridRefresh("Авторизация");
            conn.ConnectionClose();
            
        }

        private void dataManager_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            conn.ConnectionOpen();
            if (e.ColumnIndex == 0)
            {
                string res = MessageBox.Show("Вы точно хотите удалить эту строку?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question).ToString();
                try
                {
                    if (res == "Yes")
                    {
                        var cmd = new SqlCommand($"delete from Менеджеры where idМенеджера='{dataManager.Rows[e.RowIndex].Cells[1].Value}'", conn.SqlConnection);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch
                {
                    MessageBox.Show("У данного менеджера существует заказ или он присутствует в таблице Авторизации.");
                }
               
            }
            dataManager.DataGridRefresh("Менеджеры");
            conn.ConnectionClose();
            
        }
    }
}
