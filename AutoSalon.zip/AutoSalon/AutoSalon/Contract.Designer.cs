﻿namespace AutoSalon
{
    partial class Contract
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxContract = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCreateContract = new System.Windows.Forms.Button();
            this.dateCreateContract = new System.Windows.Forms.DateTimePicker();
            this.dateExpiresContract = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Номер договора :";
            // 
            // textBoxContract
            // 
            this.textBoxContract.Location = new System.Drawing.Point(128, 23);
            this.textBoxContract.MaxLength = 8;
            this.textBoxContract.Name = "textBoxContract";
            this.textBoxContract.Size = new System.Drawing.Size(126, 20);
            this.textBoxContract.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Дата заключения :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Договор истекает :";
            // 
            // btnCreateContract
            // 
            this.btnCreateContract.Location = new System.Drawing.Point(77, 142);
            this.btnCreateContract.Name = "btnCreateContract";
            this.btnCreateContract.Size = new System.Drawing.Size(130, 49);
            this.btnCreateContract.TabIndex = 6;
            this.btnCreateContract.Text = "Создать";
            this.btnCreateContract.UseVisualStyleBackColor = true;
            this.btnCreateContract.Click += new System.EventHandler(this.btnCreateContract_Click);
            // 
            // dateCreateContract
            // 
            this.dateCreateContract.Location = new System.Drawing.Point(128, 58);
            this.dateCreateContract.MaxDate = new System.DateTime(3000, 12, 31, 0, 0, 0, 0);
            this.dateCreateContract.Name = "dateCreateContract";
            this.dateCreateContract.Size = new System.Drawing.Size(126, 20);
            this.dateCreateContract.TabIndex = 7;
            // 
            // dateExpiresContract
            // 
            this.dateExpiresContract.Location = new System.Drawing.Point(128, 95);
            this.dateExpiresContract.MaxDate = new System.DateTime(3000, 12, 31, 0, 0, 0, 0);
            this.dateExpiresContract.Name = "dateExpiresContract";
            this.dateExpiresContract.Size = new System.Drawing.Size(126, 20);
            this.dateExpiresContract.TabIndex = 8;
            // 
            // Contract
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(277, 215);
            this.Controls.Add(this.dateExpiresContract);
            this.Controls.Add(this.dateCreateContract);
            this.Controls.Add(this.btnCreateContract);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxContract);
            this.Controls.Add(this.label1);
            this.Name = "Contract";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Договор поставщика";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Contract_FormClosed);
            this.Load += new System.EventHandler(this.Contract_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxContract;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCreateContract;
        private System.Windows.Forms.DateTimePicker dateCreateContract;
        private System.Windows.Forms.DateTimePicker dateExpiresContract;
    }
}