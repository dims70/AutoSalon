﻿using System;
using System.Windows.Forms;

namespace AutoSalon
{/// <summary>
/// Форма.АдминПанель
/// </summary>
    public partial class AdminPanelAuth : Form
    { MainForm forms;
        public AdminPanelAuth(MainForm form)
        {
            InitializeComponent();
            forms = form;
        }
        private void btnAdminAuth_Click(object sender, EventArgs e)
        {   

            if (login_box_admin.Text=="admin" && pass_box_admin.Text=="1234")
            {
                new AdminPanel().Show();
            }
            else MessageBox.Show("Введите верный логин и пароль");

        }

        private void AdminPanel_FormClosed(object sender, FormClosedEventArgs e) => forms.Show();

    }
}
