﻿using System;
namespace AutoSalon
{   /// <summary>
    /// Класс договора
    /// </summary>
    public class Contr
    {
        public string NumberContract { get; set; }
        public string dateCreate { get; set; }
        public string dateExpires { get; set; }
        /// <summary>
        /// Конструктор создания договора
        /// </summary>
        /// <param name="_nc">Номер договора</param>
        /// <param name="_dc">Дата создания</param>
        /// <param name="_de">Дата истечения</param>
        public Contr(string _nc,string _dc, string _de)
        {
            NumberContract = _nc;
            dateCreate = _dc;
            dateExpires = _de;
        }
    }
}
