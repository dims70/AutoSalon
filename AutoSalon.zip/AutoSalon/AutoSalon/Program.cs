﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoSalon
{
    public class Program : ApplicationContext
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        //static public ApplicationContext AppCont { get; set; } = new ApplicationContext();
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
            //AppCont.MainForm = new AdminPanel();
            //Application.Run(AppCont.MainForm);


        }

    }
}
