﻿namespace AutoSalon
{
    partial class InterfaceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.LeftTabControl = new System.Windows.Forms.TabControl();
            this.LeftPage1 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.ComboDistBox = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ComboAutoBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnCreateOrder = new System.Windows.Forms.Button();
            this.PassportBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.PhoneBox = new System.Windows.Forms.TextBox();
            this.AdrBox = new System.Windows.Forms.TextBox();
            this.FIOBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LeftPage2 = new System.Windows.Forms.TabPage();
            this.btnCreateSupp = new System.Windows.Forms.Button();
            this.dateSupply = new System.Windows.Forms.DateTimePicker();
            this.NumberBoxSupp = new System.Windows.Forms.TextBox();
            this.SummSupp = new System.Windows.Forms.TextBox();
            this.SuppAutoBox = new System.Windows.Forms.ComboBox();
            this.SuppPostBox = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.LeftPage3 = new System.Windows.Forms.TabPage();
            this.BoxNumberContractSupplier = new System.Windows.Forms.ComboBox();
            this.textBoxAdressSupplier = new System.Windows.Forms.TextBox();
            this.textBoxPhoneSupplier = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBoxNameSupplier = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.btnCreateSupplier = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.LeftPage4 = new System.Windows.Forms.TabPage();
            this.CostForKm = new System.Windows.Forms.TextBox();
            this.BoxTypeDist = new System.Windows.Forms.ComboBox();
            this.textBoxPhoneDist = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.NameDist = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.btnCreateDist = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.LeftPage5 = new System.Windows.Forms.TabPage();
            this.label46 = new System.Windows.Forms.Label();
            this.btnSaveAuto = new System.Windows.Forms.Button();
            this.textBoxCost = new System.Windows.Forms.TextBox();
            this.textBoxComplect = new System.Windows.Forms.TextBox();
            this.textBoxCYear = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBoxColor = new System.Windows.Forms.TextBox();
            this.textBoxTBody = new System.Windows.Forms.TextBox();
            this.textBoxTBuild = new System.Windows.Forms.TextBox();
            this.textBoxCLass = new System.Windows.Forms.TextBox();
            this.textBoxModel = new System.Windows.Forms.TextBox();
            this.textBoxStamp = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.LeftPage6 = new System.Windows.Forms.TabPage();
            this.RightTabControl = new System.Windows.Forms.TabControl();
            this.RightPage1 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.dataListOrder = new System.Windows.Forms.DataGridView();
            this.RightPage2 = new System.Windows.Forms.TabPage();
            this.label22 = new System.Windows.Forms.Label();
            this.dataSuppView = new System.Windows.Forms.DataGridView();
            this.RightPage3 = new System.Windows.Forms.TabPage();
            this.dataListSupp = new System.Windows.Forms.DataGridView();
            this.label23 = new System.Windows.Forms.Label();
            this.RightPage4 = new System.Windows.Forms.TabPage();
            this.dataListDist = new System.Windows.Forms.DataGridView();
            this.label24 = new System.Windows.Forms.Label();
            this.RightPage5 = new System.Windows.Forms.TabPage();
            this.dataListAuto = new System.Windows.Forms.DataGridView();
            this.label25 = new System.Windows.Forms.Label();
            this.RightPage6 = new System.Windows.Forms.TabPage();
            this.dataListContract = new System.Windows.Forms.DataGridView();
            this.label26 = new System.Windows.Forms.Label();
            this.btnOrder = new System.Windows.Forms.Button();
            this.btnSupply = new System.Windows.Forms.Button();
            this.btnSupplier = new System.Windows.Forms.Button();
            this.btnDist = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnAuto = new System.Windows.Forms.Button();
            this.btnListContract = new System.Windows.Forms.Button();
            this.dateExpiresContract = new System.Windows.Forms.DateTimePicker();
            this.dateCreateContract = new System.Windows.Forms.DateTimePicker();
            this.btnCreateContract = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.textBoxContract = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.LeftTabControl.SuspendLayout();
            this.LeftPage1.SuspendLayout();
            this.LeftPage2.SuspendLayout();
            this.LeftPage3.SuspendLayout();
            this.LeftPage4.SuspendLayout();
            this.LeftPage5.SuspendLayout();
            this.LeftPage6.SuspendLayout();
            this.RightTabControl.SuspendLayout();
            this.RightPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListOrder)).BeginInit();
            this.RightPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSuppView)).BeginInit();
            this.RightPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListSupp)).BeginInit();
            this.RightPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListDist)).BeginInit();
            this.RightPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListAuto)).BeginInit();
            this.RightPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListContract)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(714, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(625, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Пользователь:";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(12, 9);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.LeftTabControl);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.RightTabControl);
            this.splitContainer1.Size = new System.Drawing.Size(607, 361);
            this.splitContainer1.SplitterDistance = 279;
            this.splitContainer1.TabIndex = 2;
            // 
            // LeftTabControl
            // 
            this.LeftTabControl.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.LeftTabControl.Controls.Add(this.LeftPage1);
            this.LeftTabControl.Controls.Add(this.LeftPage2);
            this.LeftTabControl.Controls.Add(this.LeftPage3);
            this.LeftTabControl.Controls.Add(this.LeftPage4);
            this.LeftTabControl.Controls.Add(this.LeftPage5);
            this.LeftTabControl.Controls.Add(this.LeftPage6);
            this.LeftTabControl.ItemSize = new System.Drawing.Size(96, 18);
            this.LeftTabControl.Location = new System.Drawing.Point(0, 3);
            this.LeftTabControl.Name = "LeftTabControl";
            this.LeftTabControl.SelectedIndex = 0;
            this.LeftTabControl.Size = new System.Drawing.Size(284, 355);
            this.LeftTabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.LeftTabControl.TabIndex = 0;
            // 
            // LeftPage1
            // 
            this.LeftPage1.BackColor = System.Drawing.Color.LemonChiffon;
            this.LeftPage1.Controls.Add(this.label15);
            this.LeftPage1.Controls.Add(this.label14);
            this.LeftPage1.Controls.Add(this.label13);
            this.LeftPage1.Controls.Add(this.label12);
            this.LeftPage1.Controls.Add(this.ComboDistBox);
            this.LeftPage1.Controls.Add(this.label11);
            this.LeftPage1.Controls.Add(this.ComboAutoBox);
            this.LeftPage1.Controls.Add(this.label10);
            this.LeftPage1.Controls.Add(this.btnCreateOrder);
            this.LeftPage1.Controls.Add(this.PassportBox);
            this.LeftPage1.Controls.Add(this.label8);
            this.LeftPage1.Controls.Add(this.PhoneBox);
            this.LeftPage1.Controls.Add(this.AdrBox);
            this.LeftPage1.Controls.Add(this.FIOBox);
            this.LeftPage1.Controls.Add(this.label7);
            this.LeftPage1.Controls.Add(this.label6);
            this.LeftPage1.Controls.Add(this.label5);
            this.LeftPage1.Controls.Add(this.label4);
            this.LeftPage1.Location = new System.Drawing.Point(4, 22);
            this.LeftPage1.Name = "LeftPage1";
            this.LeftPage1.Padding = new System.Windows.Forms.Padding(3);
            this.LeftPage1.Size = new System.Drawing.Size(276, 329);
            this.LeftPage1.TabIndex = 0;
            this.LeftPage1.Text = "tabPage1";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(193, 148);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 13);
            this.label15.TabIndex = 17;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(122, 148);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "Стоимость:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(58, 148);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 13);
            this.label13.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(22, 148);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "Дата:";
            // 
            // ComboDistBox
            // 
            this.ComboDistBox.FormattingEnabled = true;
            this.ComboDistBox.Location = new System.Drawing.Point(73, 239);
            this.ComboDistBox.Name = "ComboDistBox";
            this.ComboDistBox.Size = new System.Drawing.Size(127, 21);
            this.ComboDistBox.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(99, 223);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "Перегонщик:";
            // 
            // ComboAutoBox
            // 
            this.ComboAutoBox.FormattingEnabled = true;
            this.ComboAutoBox.Location = new System.Drawing.Point(73, 191);
            this.ComboAutoBox.Name = "ComboAutoBox";
            this.ComboAutoBox.Size = new System.Drawing.Size(127, 21);
            this.ComboAutoBox.TabIndex = 11;
            this.ComboAutoBox.SelectedIndexChanged += new System.EventHandler(this.ComboAutoBox_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(99, 175);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Автомобиль:";
            // 
            // btnCreateOrder
            // 
            this.btnCreateOrder.Location = new System.Drawing.Point(73, 284);
            this.btnCreateOrder.Name = "btnCreateOrder";
            this.btnCreateOrder.Size = new System.Drawing.Size(127, 40);
            this.btnCreateOrder.TabIndex = 9;
            this.btnCreateOrder.Text = "Создать заказ";
            this.btnCreateOrder.UseVisualStyleBackColor = true;
            this.btnCreateOrder.Click += new System.EventHandler(this.btnCreateOrder_Click);
            // 
            // PassportBox
            // 
            this.PassportBox.Location = new System.Drawing.Point(67, 117);
            this.PassportBox.MaxLength = 10;
            this.PassportBox.Name = "PassportBox";
            this.PassportBox.Size = new System.Drawing.Size(192, 20);
            this.PassportBox.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 121);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Паспорт:";
            // 
            // PhoneBox
            // 
            this.PhoneBox.Location = new System.Drawing.Point(67, 91);
            this.PhoneBox.MaxLength = 11;
            this.PhoneBox.Name = "PhoneBox";
            this.PhoneBox.Size = new System.Drawing.Size(192, 20);
            this.PhoneBox.TabIndex = 6;
            // 
            // AdrBox
            // 
            this.AdrBox.Location = new System.Drawing.Point(67, 65);
            this.AdrBox.MaxLength = 15;
            this.AdrBox.Name = "AdrBox";
            this.AdrBox.Size = new System.Drawing.Size(192, 20);
            this.AdrBox.TabIndex = 5;
            // 
            // FIOBox
            // 
            this.FIOBox.Location = new System.Drawing.Point(67, 39);
            this.FIOBox.MaxLength = 50;
            this.FIOBox.Name = "FIOBox";
            this.FIOBox.Size = new System.Drawing.Size(192, 20);
            this.FIOBox.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Телефон :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Адрес :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "ФИО :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(73, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Заполнение данных";
            // 
            // LeftPage2
            // 
            this.LeftPage2.BackColor = System.Drawing.Color.LemonChiffon;
            this.LeftPage2.Controls.Add(this.btnCreateSupp);
            this.LeftPage2.Controls.Add(this.dateSupply);
            this.LeftPage2.Controls.Add(this.NumberBoxSupp);
            this.LeftPage2.Controls.Add(this.SummSupp);
            this.LeftPage2.Controls.Add(this.SuppAutoBox);
            this.LeftPage2.Controls.Add(this.SuppPostBox);
            this.LeftPage2.Controls.Add(this.label21);
            this.LeftPage2.Controls.Add(this.label20);
            this.LeftPage2.Controls.Add(this.label19);
            this.LeftPage2.Controls.Add(this.label18);
            this.LeftPage2.Controls.Add(this.label17);
            this.LeftPage2.Controls.Add(this.label16);
            this.LeftPage2.Location = new System.Drawing.Point(4, 22);
            this.LeftPage2.Name = "LeftPage2";
            this.LeftPage2.Padding = new System.Windows.Forms.Padding(3);
            this.LeftPage2.Size = new System.Drawing.Size(265, 329);
            this.LeftPage2.TabIndex = 1;
            this.LeftPage2.Text = "tabPage2";
            // 
            // btnCreateSupp
            // 
            this.btnCreateSupp.Location = new System.Drawing.Point(61, 226);
            this.btnCreateSupp.Name = "btnCreateSupp";
            this.btnCreateSupp.Size = new System.Drawing.Size(148, 42);
            this.btnCreateSupp.TabIndex = 12;
            this.btnCreateSupp.Text = "Создать поставку";
            this.btnCreateSupp.UseVisualStyleBackColor = true;
            this.btnCreateSupp.Click += new System.EventHandler(this.btnCreateSupp_Click);
            // 
            // dateSupply
            // 
            this.dateSupply.Location = new System.Drawing.Point(121, 56);
            this.dateSupply.Name = "dateSupply";
            this.dateSupply.Size = new System.Drawing.Size(122, 20);
            this.dateSupply.TabIndex = 11;
            // 
            // NumberBoxSupp
            // 
            this.NumberBoxSupp.Location = new System.Drawing.Point(122, 109);
            this.NumberBoxSupp.Name = "NumberBoxSupp";
            this.NumberBoxSupp.Size = new System.Drawing.Size(121, 20);
            this.NumberBoxSupp.TabIndex = 9;
            this.NumberBoxSupp.TextChanged += new System.EventHandler(this.NumberBoxSupp_TextChanged);
            // 
            // SummSupp
            // 
            this.SummSupp.Location = new System.Drawing.Point(121, 135);
            this.SummSupp.Name = "SummSupp";
            this.SummSupp.Size = new System.Drawing.Size(121, 20);
            this.SummSupp.TabIndex = 8;
            // 
            // SuppAutoBox
            // 
            this.SuppAutoBox.FormattingEnabled = true;
            this.SuppAutoBox.Items.AddRange(new object[] {
            "новый..."});
            this.SuppAutoBox.Location = new System.Drawing.Point(122, 82);
            this.SuppAutoBox.Name = "SuppAutoBox";
            this.SuppAutoBox.Size = new System.Drawing.Size(121, 21);
            this.SuppAutoBox.TabIndex = 7;
            this.SuppAutoBox.SelectedIndexChanged += new System.EventHandler(this.SuppAutoBox_SelectedIndexChanged);
            // 
            // SuppPostBox
            // 
            this.SuppPostBox.FormattingEnabled = true;
            this.SuppPostBox.Location = new System.Drawing.Point(121, 161);
            this.SuppPostBox.Name = "SuppPostBox";
            this.SuppPostBox.Size = new System.Drawing.Size(121, 21);
            this.SuppPostBox.TabIndex = 6;
            this.SuppPostBox.SelectedIndexChanged += new System.EventHandler(this.SuppPostBox_SelectedIndexChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(34, 164);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 13);
            this.label21.TabIndex = 5;
            this.label21.Text = "Поставщик:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(30, 138);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(74, 13);
            this.label20.TabIndex = 4;
            this.label20.Text = "Цена партии:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(33, 112);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(69, 13);
            this.label19.TabIndex = 3;
            this.label19.Text = "Количество:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(33, 85);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "Автомобиль:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label17.Location = new System.Drawing.Point(45, 13);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(189, 20);
            this.label17.TabIndex = 1;
            this.label17.Text = "Оформление поставки:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(31, 57);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Дата поставки:";
            // 
            // LeftPage3
            // 
            this.LeftPage3.BackColor = System.Drawing.Color.LemonChiffon;
            this.LeftPage3.Controls.Add(this.BoxNumberContractSupplier);
            this.LeftPage3.Controls.Add(this.textBoxAdressSupplier);
            this.LeftPage3.Controls.Add(this.textBoxPhoneSupplier);
            this.LeftPage3.Controls.Add(this.label28);
            this.LeftPage3.Controls.Add(this.label29);
            this.LeftPage3.Controls.Add(this.label30);
            this.LeftPage3.Controls.Add(this.textBoxNameSupplier);
            this.LeftPage3.Controls.Add(this.label31);
            this.LeftPage3.Controls.Add(this.btnCreateSupplier);
            this.LeftPage3.Controls.Add(this.label27);
            this.LeftPage3.Location = new System.Drawing.Point(4, 22);
            this.LeftPage3.Name = "LeftPage3";
            this.LeftPage3.Padding = new System.Windows.Forms.Padding(3);
            this.LeftPage3.Size = new System.Drawing.Size(265, 329);
            this.LeftPage3.TabIndex = 2;
            this.LeftPage3.Text = "tabPage1";
            // 
            // BoxNumberContractSupplier
            // 
            this.BoxNumberContractSupplier.FormattingEnabled = true;
            this.BoxNumberContractSupplier.Location = new System.Drawing.Point(54, 222);
            this.BoxNumberContractSupplier.Name = "BoxNumberContractSupplier";
            this.BoxNumberContractSupplier.Size = new System.Drawing.Size(142, 21);
            this.BoxNumberContractSupplier.TabIndex = 15;
            // 
            // textBoxAdressSupplier
            // 
            this.textBoxAdressSupplier.Location = new System.Drawing.Point(53, 176);
            this.textBoxAdressSupplier.MaxLength = 50;
            this.textBoxAdressSupplier.Name = "textBoxAdressSupplier";
            this.textBoxAdressSupplier.Size = new System.Drawing.Size(142, 20);
            this.textBoxAdressSupplier.TabIndex = 14;
            // 
            // textBoxPhoneSupplier
            // 
            this.textBoxPhoneSupplier.Location = new System.Drawing.Point(55, 126);
            this.textBoxPhoneSupplier.MaxLength = 11;
            this.textBoxPhoneSupplier.Name = "textBoxPhoneSupplier";
            this.textBoxPhoneSupplier.Size = new System.Drawing.Size(141, 20);
            this.textBoxPhoneSupplier.TabIndex = 13;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(77, 206);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(94, 13);
            this.label28.TabIndex = 12;
            this.label28.Text = "Номер договора:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(107, 160);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(41, 13);
            this.label29.TabIndex = 11;
            this.label29.Text = "Адрес:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(93, 110);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 13);
            this.label30.TabIndex = 10;
            this.label30.Text = "Телефон:";
            // 
            // textBoxNameSupplier
            // 
            this.textBoxNameSupplier.Location = new System.Drawing.Point(54, 80);
            this.textBoxNameSupplier.MaxLength = 50;
            this.textBoxNameSupplier.Name = "textBoxNameSupplier";
            this.textBoxNameSupplier.Size = new System.Drawing.Size(141, 20);
            this.textBoxNameSupplier.TabIndex = 9;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(61, 64);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(125, 13);
            this.label31.TabIndex = 8;
            this.label31.Text = "Название поставщика:";
            // 
            // btnCreateSupplier
            // 
            this.btnCreateSupplier.Location = new System.Drawing.Point(53, 266);
            this.btnCreateSupplier.Name = "btnCreateSupplier";
            this.btnCreateSupplier.Size = new System.Drawing.Size(142, 43);
            this.btnCreateSupplier.TabIndex = 1;
            this.btnCreateSupplier.Text = "Создать поставщика";
            this.btnCreateSupplier.UseVisualStyleBackColor = true;
            this.btnCreateSupplier.Click += new System.EventHandler(this.btnCreateSupplier_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label27.Location = new System.Drawing.Point(52, 28);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(155, 17);
            this.label27.TabIndex = 0;
            this.label27.Text = "Создание поставщика";
            // 
            // LeftPage4
            // 
            this.LeftPage4.BackColor = System.Drawing.Color.LemonChiffon;
            this.LeftPage4.Controls.Add(this.CostForKm);
            this.LeftPage4.Controls.Add(this.BoxTypeDist);
            this.LeftPage4.Controls.Add(this.textBoxPhoneDist);
            this.LeftPage4.Controls.Add(this.label33);
            this.LeftPage4.Controls.Add(this.label34);
            this.LeftPage4.Controls.Add(this.label35);
            this.LeftPage4.Controls.Add(this.NameDist);
            this.LeftPage4.Controls.Add(this.label36);
            this.LeftPage4.Controls.Add(this.btnCreateDist);
            this.LeftPage4.Controls.Add(this.label32);
            this.LeftPage4.Location = new System.Drawing.Point(4, 22);
            this.LeftPage4.Name = "LeftPage4";
            this.LeftPage4.Padding = new System.Windows.Forms.Padding(3);
            this.LeftPage4.Size = new System.Drawing.Size(265, 329);
            this.LeftPage4.TabIndex = 3;
            this.LeftPage4.Text = "tabPage1";
            // 
            // CostForKm
            // 
            this.CostForKm.Location = new System.Drawing.Point(57, 215);
            this.CostForKm.MaxLength = 11;
            this.CostForKm.Name = "CostForKm";
            this.CostForKm.Size = new System.Drawing.Size(141, 20);
            this.CostForKm.TabIndex = 24;
            // 
            // BoxTypeDist
            // 
            this.BoxTypeDist.FormattingEnabled = true;
            this.BoxTypeDist.Items.AddRange(new object[] {
            "Медленная",
            "Средняя",
            "Быстрая"});
            this.BoxTypeDist.Location = new System.Drawing.Point(57, 166);
            this.BoxTypeDist.Name = "BoxTypeDist";
            this.BoxTypeDist.Size = new System.Drawing.Size(141, 21);
            this.BoxTypeDist.TabIndex = 23;
            // 
            // textBoxPhoneDist
            // 
            this.textBoxPhoneDist.Location = new System.Drawing.Point(57, 110);
            this.textBoxPhoneDist.MaxLength = 11;
            this.textBoxPhoneDist.Name = "textBoxPhoneDist";
            this.textBoxPhoneDist.Size = new System.Drawing.Size(141, 20);
            this.textBoxPhoneDist.TabIndex = 22;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(79, 199);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(97, 13);
            this.label33.TabIndex = 21;
            this.label33.Text = "Стоимость за км:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(79, 150);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(85, 13);
            this.label34.TabIndex = 20;
            this.label34.Text = "Тип перегонки:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(95, 94);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(55, 13);
            this.label35.TabIndex = 19;
            this.label35.Text = "Телефон:";
            // 
            // NameDist
            // 
            this.NameDist.Location = new System.Drawing.Point(56, 64);
            this.NameDist.MaxLength = 50;
            this.NameDist.Name = "NameDist";
            this.NameDist.Size = new System.Drawing.Size(141, 20);
            this.NameDist.TabIndex = 18;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(63, 48);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(113, 13);
            this.label36.TabIndex = 17;
            this.label36.Text = "Название компании:";
            // 
            // btnCreateDist
            // 
            this.btnCreateDist.Location = new System.Drawing.Point(55, 250);
            this.btnCreateDist.Name = "btnCreateDist";
            this.btnCreateDist.Size = new System.Drawing.Size(142, 43);
            this.btnCreateDist.TabIndex = 16;
            this.btnCreateDist.Text = "Создать поставщика";
            this.btnCreateDist.UseVisualStyleBackColor = true;
            this.btnCreateDist.Click += new System.EventHandler(this.btnCreateDist_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label32.Location = new System.Drawing.Point(54, 13);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(153, 17);
            this.label32.TabIndex = 0;
            this.label32.Text = "Создать перегонщика";
            // 
            // LeftPage5
            // 
            this.LeftPage5.BackColor = System.Drawing.Color.LemonChiffon;
            this.LeftPage5.Controls.Add(this.label46);
            this.LeftPage5.Controls.Add(this.btnSaveAuto);
            this.LeftPage5.Controls.Add(this.textBoxCost);
            this.LeftPage5.Controls.Add(this.textBoxComplect);
            this.LeftPage5.Controls.Add(this.textBoxCYear);
            this.LeftPage5.Controls.Add(this.label37);
            this.LeftPage5.Controls.Add(this.label38);
            this.LeftPage5.Controls.Add(this.label39);
            this.LeftPage5.Controls.Add(this.textBoxColor);
            this.LeftPage5.Controls.Add(this.textBoxTBody);
            this.LeftPage5.Controls.Add(this.textBoxTBuild);
            this.LeftPage5.Controls.Add(this.textBoxCLass);
            this.LeftPage5.Controls.Add(this.textBoxModel);
            this.LeftPage5.Controls.Add(this.textBoxStamp);
            this.LeftPage5.Controls.Add(this.label40);
            this.LeftPage5.Controls.Add(this.label41);
            this.LeftPage5.Controls.Add(this.label42);
            this.LeftPage5.Controls.Add(this.label43);
            this.LeftPage5.Controls.Add(this.label44);
            this.LeftPage5.Controls.Add(this.label45);
            this.LeftPage5.Location = new System.Drawing.Point(4, 22);
            this.LeftPage5.Name = "LeftPage5";
            this.LeftPage5.Padding = new System.Windows.Forms.Padding(3);
            this.LeftPage5.Size = new System.Drawing.Size(265, 329);
            this.LeftPage5.TabIndex = 4;
            this.LeftPage5.Text = "tabPage1";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(63, 11);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(137, 13);
            this.label46.TabIndex = 38;
            this.label46.Text = "Добавление автомобиля:";
            // 
            // btnSaveAuto
            // 
            this.btnSaveAuto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnSaveAuto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSaveAuto.Location = new System.Drawing.Point(80, 281);
            this.btnSaveAuto.Name = "btnSaveAuto";
            this.btnSaveAuto.Size = new System.Drawing.Size(116, 36);
            this.btnSaveAuto.TabIndex = 37;
            this.btnSaveAuto.Text = "Сохранить";
            this.btnSaveAuto.UseVisualStyleBackColor = false;
            this.btnSaveAuto.Click += new System.EventHandler(this.btnSaveAuto_Click);
            // 
            // textBoxCost
            // 
            this.textBoxCost.Location = new System.Drawing.Point(115, 240);
            this.textBoxCost.Name = "textBoxCost";
            this.textBoxCost.Size = new System.Drawing.Size(100, 20);
            this.textBoxCost.TabIndex = 36;
            // 
            // textBoxComplect
            // 
            this.textBoxComplect.Location = new System.Drawing.Point(115, 214);
            this.textBoxComplect.Name = "textBoxComplect";
            this.textBoxComplect.Size = new System.Drawing.Size(100, 20);
            this.textBoxComplect.TabIndex = 35;
            // 
            // textBoxCYear
            // 
            this.textBoxCYear.Location = new System.Drawing.Point(115, 188);
            this.textBoxCYear.Name = "textBoxCYear";
            this.textBoxCYear.Size = new System.Drawing.Size(100, 20);
            this.textBoxCYear.TabIndex = 34;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(39, 243);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 13);
            this.label37.TabIndex = 33;
            this.label37.Text = "Стоимость:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(20, 217);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(84, 13);
            this.label38.TabIndex = 32;
            this.label38.Text = "Комплектация:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(2, 191);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(102, 13);
            this.label39.TabIndex = 31;
            this.label39.Text = "Год производства:";
            // 
            // textBoxColor
            // 
            this.textBoxColor.Location = new System.Drawing.Point(115, 162);
            this.textBoxColor.Name = "textBoxColor";
            this.textBoxColor.Size = new System.Drawing.Size(100, 20);
            this.textBoxColor.TabIndex = 30;
            // 
            // textBoxTBody
            // 
            this.textBoxTBody.Location = new System.Drawing.Point(115, 136);
            this.textBoxTBody.Name = "textBoxTBody";
            this.textBoxTBody.Size = new System.Drawing.Size(100, 20);
            this.textBoxTBody.TabIndex = 29;
            // 
            // textBoxTBuild
            // 
            this.textBoxTBuild.Location = new System.Drawing.Point(115, 110);
            this.textBoxTBuild.Name = "textBoxTBuild";
            this.textBoxTBuild.Size = new System.Drawing.Size(100, 20);
            this.textBoxTBuild.TabIndex = 28;
            // 
            // textBoxCLass
            // 
            this.textBoxCLass.Location = new System.Drawing.Point(115, 84);
            this.textBoxCLass.Name = "textBoxCLass";
            this.textBoxCLass.Size = new System.Drawing.Size(100, 20);
            this.textBoxCLass.TabIndex = 27;
            // 
            // textBoxModel
            // 
            this.textBoxModel.Location = new System.Drawing.Point(115, 58);
            this.textBoxModel.Name = "textBoxModel";
            this.textBoxModel.Size = new System.Drawing.Size(100, 20);
            this.textBoxModel.TabIndex = 26;
            // 
            // textBoxStamp
            // 
            this.textBoxStamp.Location = new System.Drawing.Point(115, 32);
            this.textBoxStamp.Name = "textBoxStamp";
            this.textBoxStamp.Size = new System.Drawing.Size(100, 20);
            this.textBoxStamp.TabIndex = 25;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(63, 165);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(35, 13);
            this.label40.TabIndex = 24;
            this.label40.Text = "Цвет:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(31, 139);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(67, 13);
            this.label41.TabIndex = 23;
            this.label41.Text = "Тип кузова:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(31, 113);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(68, 13);
            this.label42.TabIndex = 22;
            this.label42.Text = "Тип сборки:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(57, 87);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(41, 13);
            this.label43.TabIndex = 21;
            this.label43.Text = "Класс:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(49, 61);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(49, 13);
            this.label44.TabIndex = 20;
            this.label44.Text = "Модель:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(55, 35);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(43, 13);
            this.label45.TabIndex = 19;
            this.label45.Text = "Марка:";
            // 
            // LeftPage6
            // 
            this.LeftPage6.BackColor = System.Drawing.Color.LemonChiffon;
            this.LeftPage6.Controls.Add(this.label50);
            this.LeftPage6.Controls.Add(this.dateExpiresContract);
            this.LeftPage6.Controls.Add(this.dateCreateContract);
            this.LeftPage6.Controls.Add(this.btnCreateContract);
            this.LeftPage6.Controls.Add(this.label47);
            this.LeftPage6.Controls.Add(this.label48);
            this.LeftPage6.Controls.Add(this.textBoxContract);
            this.LeftPage6.Controls.Add(this.label49);
            this.LeftPage6.Location = new System.Drawing.Point(4, 22);
            this.LeftPage6.Name = "LeftPage6";
            this.LeftPage6.Padding = new System.Windows.Forms.Padding(3);
            this.LeftPage6.Size = new System.Drawing.Size(265, 329);
            this.LeftPage6.TabIndex = 5;
            this.LeftPage6.Text = "tabPage1";
            // 
            // RightTabControl
            // 
            this.RightTabControl.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.RightTabControl.Controls.Add(this.RightPage1);
            this.RightTabControl.Controls.Add(this.RightPage2);
            this.RightTabControl.Controls.Add(this.RightPage3);
            this.RightTabControl.Controls.Add(this.RightPage4);
            this.RightTabControl.Controls.Add(this.RightPage5);
            this.RightTabControl.Controls.Add(this.RightPage6);
            this.RightTabControl.Location = new System.Drawing.Point(3, 3);
            this.RightTabControl.Name = "RightTabControl";
            this.RightTabControl.SelectedIndex = 0;
            this.RightTabControl.Size = new System.Drawing.Size(318, 374);
            this.RightTabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.RightTabControl.TabIndex = 1;
            // 
            // RightPage1
            // 
            this.RightPage1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RightPage1.Controls.Add(this.label9);
            this.RightPage1.Controls.Add(this.dataListOrder);
            this.RightPage1.Location = new System.Drawing.Point(4, 25);
            this.RightPage1.Name = "RightPage1";
            this.RightPage1.Padding = new System.Windows.Forms.Padding(3);
            this.RightPage1.Size = new System.Drawing.Size(310, 345);
            this.RightPage1.TabIndex = 0;
            this.RightPage1.Text = "tabPage3";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.Location = new System.Drawing.Point(95, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 17);
            this.label9.TabIndex = 2;
            this.label9.Text = "Список заказов";
            // 
            // dataListOrder
            // 
            this.dataListOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataListOrder.Location = new System.Drawing.Point(6, 28);
            this.dataListOrder.Name = "dataListOrder";
            this.dataListOrder.Size = new System.Drawing.Size(298, 315);
            this.dataListOrder.TabIndex = 1;
            // 
            // RightPage2
            // 
            this.RightPage2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RightPage2.Controls.Add(this.label22);
            this.RightPage2.Controls.Add(this.dataSuppView);
            this.RightPage2.Location = new System.Drawing.Point(4, 25);
            this.RightPage2.Name = "RightPage2";
            this.RightPage2.Padding = new System.Windows.Forms.Padding(3);
            this.RightPage2.Size = new System.Drawing.Size(310, 345);
            this.RightPage2.TabIndex = 1;
            this.RightPage2.Text = "tabPage4";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label22.Location = new System.Drawing.Point(88, 8);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(119, 17);
            this.label22.TabIndex = 3;
            this.label22.Text = "Список поставок";
            // 
            // dataSuppView
            // 
            this.dataSuppView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSuppView.Location = new System.Drawing.Point(7, 28);
            this.dataSuppView.Name = "dataSuppView";
            this.dataSuppView.Size = new System.Drawing.Size(297, 321);
            this.dataSuppView.TabIndex = 0;
            // 
            // RightPage3
            // 
            this.RightPage3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RightPage3.Controls.Add(this.dataListSupp);
            this.RightPage3.Controls.Add(this.label23);
            this.RightPage3.Location = new System.Drawing.Point(4, 25);
            this.RightPage3.Name = "RightPage3";
            this.RightPage3.Padding = new System.Windows.Forms.Padding(3);
            this.RightPage3.Size = new System.Drawing.Size(310, 345);
            this.RightPage3.TabIndex = 2;
            this.RightPage3.Text = "tabPage1";
            // 
            // dataListSupp
            // 
            this.dataListSupp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataListSupp.Location = new System.Drawing.Point(6, 28);
            this.dataListSupp.Name = "dataListSupp";
            this.dataListSupp.Size = new System.Drawing.Size(297, 321);
            this.dataListSupp.TabIndex = 5;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label23.Location = new System.Drawing.Point(91, 8);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(145, 17);
            this.label23.TabIndex = 4;
            this.label23.Text = "Список поставщиков";
            // 
            // RightPage4
            // 
            this.RightPage4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RightPage4.Controls.Add(this.dataListDist);
            this.RightPage4.Controls.Add(this.label24);
            this.RightPage4.Location = new System.Drawing.Point(4, 25);
            this.RightPage4.Name = "RightPage4";
            this.RightPage4.Padding = new System.Windows.Forms.Padding(3);
            this.RightPage4.Size = new System.Drawing.Size(310, 345);
            this.RightPage4.TabIndex = 3;
            this.RightPage4.Text = "tabPage1";
            // 
            // dataListDist
            // 
            this.dataListDist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataListDist.Location = new System.Drawing.Point(7, 27);
            this.dataListDist.Name = "dataListDist";
            this.dataListDist.Size = new System.Drawing.Size(297, 322);
            this.dataListDist.TabIndex = 7;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label24.Location = new System.Drawing.Point(85, 7);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(153, 17);
            this.label24.TabIndex = 6;
            this.label24.Text = "Список перегонщиков";
            // 
            // RightPage5
            // 
            this.RightPage5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RightPage5.Controls.Add(this.dataListAuto);
            this.RightPage5.Controls.Add(this.label25);
            this.RightPage5.Location = new System.Drawing.Point(4, 25);
            this.RightPage5.Name = "RightPage5";
            this.RightPage5.Padding = new System.Windows.Forms.Padding(3);
            this.RightPage5.Size = new System.Drawing.Size(310, 345);
            this.RightPage5.TabIndex = 4;
            this.RightPage5.Text = "tabPage2";
            // 
            // dataListAuto
            // 
            this.dataListAuto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataListAuto.Location = new System.Drawing.Point(7, 27);
            this.dataListAuto.Name = "dataListAuto";
            this.dataListAuto.Size = new System.Drawing.Size(297, 322);
            this.dataListAuto.TabIndex = 7;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label25.Location = new System.Drawing.Point(92, 7);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(146, 17);
            this.label25.TabIndex = 6;
            this.label25.Text = "Список автомобилей";
            // 
            // RightPage6
            // 
            this.RightPage6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RightPage6.Controls.Add(this.dataListContract);
            this.RightPage6.Controls.Add(this.label26);
            this.RightPage6.Location = new System.Drawing.Point(4, 25);
            this.RightPage6.Name = "RightPage6";
            this.RightPage6.Padding = new System.Windows.Forms.Padding(3);
            this.RightPage6.Size = new System.Drawing.Size(310, 345);
            this.RightPage6.TabIndex = 5;
            this.RightPage6.Text = "tabPage1";
            // 
            // dataListContract
            // 
            this.dataListContract.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataListContract.Location = new System.Drawing.Point(7, 27);
            this.dataListContract.Name = "dataListContract";
            this.dataListContract.Size = new System.Drawing.Size(297, 322);
            this.dataListContract.TabIndex = 7;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label26.Location = new System.Drawing.Point(92, 7);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(126, 17);
            this.label26.TabIndex = 6;
            this.label26.Text = "Список договоров";
            // 
            // btnOrder
            // 
            this.btnOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnOrder.Location = new System.Drawing.Point(640, 47);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(134, 56);
            this.btnOrder.TabIndex = 3;
            this.btnOrder.Text = "Оформить заказ";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrders_Click);
            // 
            // btnSupply
            // 
            this.btnSupply.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnSupply.Location = new System.Drawing.Point(640, 109);
            this.btnSupply.Name = "btnSupply";
            this.btnSupply.Size = new System.Drawing.Size(134, 45);
            this.btnSupply.TabIndex = 4;
            this.btnSupply.Text = "Создать поставку";
            this.btnSupply.UseVisualStyleBackColor = true;
            this.btnSupply.Click += new System.EventHandler(this.btnSupply_Click);
            // 
            // btnSupplier
            // 
            this.btnSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnSupplier.Location = new System.Drawing.Point(640, 160);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Size = new System.Drawing.Size(134, 43);
            this.btnSupplier.TabIndex = 5;
            this.btnSupplier.Text = "Поставщики";
            this.btnSupplier.UseVisualStyleBackColor = true;
            this.btnSupplier.Click += new System.EventHandler(this.btnSupplier_Click);
            // 
            // btnDist
            // 
            this.btnDist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnDist.Location = new System.Drawing.Point(640, 209);
            this.btnDist.Name = "btnDist";
            this.btnDist.Size = new System.Drawing.Size(134, 45);
            this.btnDist.TabIndex = 6;
            this.btnDist.Text = "Перегонщики";
            this.btnDist.UseVisualStyleBackColor = true;
            this.btnDist.Click += new System.EventHandler(this.btnDist_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(649, 357);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 7;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnAuto
            // 
            this.btnAuto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnAuto.Location = new System.Drawing.Point(640, 260);
            this.btnAuto.Name = "btnAuto";
            this.btnAuto.Size = new System.Drawing.Size(134, 48);
            this.btnAuto.TabIndex = 8;
            this.btnAuto.Text = "Автомобили";
            this.btnAuto.UseVisualStyleBackColor = true;
            this.btnAuto.Click += new System.EventHandler(this.btnAuto_Click);
            // 
            // btnListContract
            // 
            this.btnListContract.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnListContract.Location = new System.Drawing.Point(640, 315);
            this.btnListContract.Name = "btnListContract";
            this.btnListContract.Size = new System.Drawing.Size(134, 39);
            this.btnListContract.TabIndex = 9;
            this.btnListContract.Text = "Договора на поставщиков";
            this.btnListContract.UseVisualStyleBackColor = true;
            this.btnListContract.Click += new System.EventHandler(this.btnListContract_Click);
            // 
            // dateExpiresContract
            // 
            this.dateExpiresContract.Location = new System.Drawing.Point(121, 169);
            this.dateExpiresContract.MaxDate = new System.DateTime(3000, 12, 31, 0, 0, 0, 0);
            this.dateExpiresContract.Name = "dateExpiresContract";
            this.dateExpiresContract.Size = new System.Drawing.Size(126, 20);
            this.dateExpiresContract.TabIndex = 15;
            // 
            // dateCreateContract
            // 
            this.dateCreateContract.Location = new System.Drawing.Point(121, 132);
            this.dateCreateContract.MaxDate = new System.DateTime(3000, 12, 31, 0, 0, 0, 0);
            this.dateCreateContract.Name = "dateCreateContract";
            this.dateCreateContract.Size = new System.Drawing.Size(126, 20);
            this.dateCreateContract.TabIndex = 14;
            // 
            // btnCreateContract
            // 
            this.btnCreateContract.Location = new System.Drawing.Point(70, 216);
            this.btnCreateContract.Name = "btnCreateContract";
            this.btnCreateContract.Size = new System.Drawing.Size(130, 49);
            this.btnCreateContract.TabIndex = 13;
            this.btnCreateContract.Text = "Создать договор";
            this.btnCreateContract.UseVisualStyleBackColor = true;
            this.btnCreateContract.Click += new System.EventHandler(this.btnCreateContract_Click);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(15, 175);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(106, 13);
            this.label47.TabIndex = 12;
            this.label47.Text = "Договор истекает :";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(18, 138);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(103, 13);
            this.label48.TabIndex = 11;
            this.label48.Text = "Дата заключения :";
            // 
            // textBoxContract
            // 
            this.textBoxContract.Location = new System.Drawing.Point(121, 97);
            this.textBoxContract.MaxLength = 8;
            this.textBoxContract.Name = "textBoxContract";
            this.textBoxContract.Size = new System.Drawing.Size(126, 20);
            this.textBoxContract.TabIndex = 10;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(24, 100);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(97, 13);
            this.label49.TabIndex = 9;
            this.label49.Text = "Номер договора :";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label50.Location = new System.Drawing.Point(69, 75);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(122, 17);
            this.label50.TabIndex = 16;
            this.label50.Text = "Создать договор:";
            // 
            // InterfaceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 374);
            this.Controls.Add(this.btnListContract);
            this.Controls.Add(this.btnAuto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnDist);
            this.Controls.Add(this.btnSupplier);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.btnSupply);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximumSize = new System.Drawing.Size(816, 413);
            this.MinimumSize = new System.Drawing.Size(816, 413);
            this.Name = "InterfaceForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Автосалон";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.InterfaceForm_FormClosed);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.LeftTabControl.ResumeLayout(false);
            this.LeftPage1.ResumeLayout(false);
            this.LeftPage1.PerformLayout();
            this.LeftPage2.ResumeLayout(false);
            this.LeftPage2.PerformLayout();
            this.LeftPage3.ResumeLayout(false);
            this.LeftPage3.PerformLayout();
            this.LeftPage4.ResumeLayout(false);
            this.LeftPage4.PerformLayout();
            this.LeftPage5.ResumeLayout(false);
            this.LeftPage5.PerformLayout();
            this.LeftPage6.ResumeLayout(false);
            this.LeftPage6.PerformLayout();
            this.RightTabControl.ResumeLayout(false);
            this.RightPage1.ResumeLayout(false);
            this.RightPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListOrder)).EndInit();
            this.RightPage2.ResumeLayout(false);
            this.RightPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSuppView)).EndInit();
            this.RightPage3.ResumeLayout(false);
            this.RightPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListSupp)).EndInit();
            this.RightPage4.ResumeLayout(false);
            this.RightPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListDist)).EndInit();
            this.RightPage5.ResumeLayout(false);
            this.RightPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListAuto)).EndInit();
            this.RightPage6.ResumeLayout(false);
            this.RightPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListContract)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabControl LeftTabControl;
        private System.Windows.Forms.TabPage LeftPage1;
        private System.Windows.Forms.TabPage LeftPage2;
        private System.Windows.Forms.TabControl RightTabControl;
        private System.Windows.Forms.TabPage RightPage1;
        private System.Windows.Forms.TabPage RightPage2;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Button btnSupply;
        private System.Windows.Forms.Button btnSupplier;
        private System.Windows.Forms.Button btnDist;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox PassportBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox PhoneBox;
        private System.Windows.Forms.TextBox AdrBox;
        private System.Windows.Forms.TextBox FIOBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataListOrder;
        private System.Windows.Forms.DataGridView dataSuppView;
        private System.Windows.Forms.Button btnCreateOrder;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ComboDistBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox ComboAutoBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dateSupply;
        private System.Windows.Forms.TextBox NumberBoxSupp;
        private System.Windows.Forms.TextBox SummSupp;
        private System.Windows.Forms.ComboBox SuppAutoBox;
        private System.Windows.Forms.ComboBox SuppPostBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnAuto;
        private System.Windows.Forms.Button btnCreateSupp;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TabPage LeftPage3;
        private System.Windows.Forms.TabPage LeftPage4;
        private System.Windows.Forms.TabPage RightPage3;
        private System.Windows.Forms.TabPage RightPage4;
        private System.Windows.Forms.TabPage LeftPage5;
        private System.Windows.Forms.TabPage RightPage5;
        private System.Windows.Forms.Button btnListContract;
        private System.Windows.Forms.TabPage LeftPage6;
        private System.Windows.Forms.TabPage RightPage6;
        private System.Windows.Forms.DataGridView dataListSupp;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridView dataListDist;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DataGridView dataListAuto;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DataGridView dataListContract;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnCreateSupplier;
        private System.Windows.Forms.TextBox textBoxAdressSupplier;
        private System.Windows.Forms.TextBox textBoxPhoneSupplier;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBoxNameSupplier;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox BoxNumberContractSupplier;
        private System.Windows.Forms.TextBox CostForKm;
        private System.Windows.Forms.ComboBox BoxTypeDist;
        private System.Windows.Forms.TextBox textBoxPhoneDist;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox NameDist;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btnCreateDist;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button btnSaveAuto;
        private System.Windows.Forms.TextBox textBoxCost;
        private System.Windows.Forms.TextBox textBoxComplect;
        private System.Windows.Forms.TextBox textBoxCYear;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBoxColor;
        private System.Windows.Forms.TextBox textBoxTBody;
        private System.Windows.Forms.TextBox textBoxTBuild;
        private System.Windows.Forms.TextBox textBoxCLass;
        private System.Windows.Forms.TextBox textBoxModel;
        private System.Windows.Forms.TextBox textBoxStamp;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.DateTimePicker dateExpiresContract;
        private System.Windows.Forms.DateTimePicker dateCreateContract;
        private System.Windows.Forms.Button btnCreateContract;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBoxContract;
        private System.Windows.Forms.Label label49;
    }
}