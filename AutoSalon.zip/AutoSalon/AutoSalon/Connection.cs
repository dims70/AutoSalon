﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AutoSalon
{   /// <summary>
    /// Класс соединения
    /// </summary>
    class Connection
    {
        //static string strCon = @"Data Source=DIMA\SQLEXPRESS;Initial Catalog=AutoSalon;Integrated Security=True";
        static string strCon = @"Data Source=RT-1KK-PC12;Initial Catalog=AutoSalon;Integrated Security=True";
        public SqlConnection SqlConnection = new SqlConnection(strCon);
        /// <summary>
        /// Метод открытия соединения
        /// </summary>
        public void ConnectionOpen()
        {
            try
            { 
            SqlConnection.Open();
            }
            catch
            {
                MessageBox.Show("Ошибка подключения к базе данных, проверьте подключение и перезапустите программу.");
                throw new Exception("Die Connection");
            }
        }
        /// <summary>
        /// Метод закрытия соединения 
        /// </summary>
        public void ConnectionClose()
        {
            try
            {
                SqlConnection.Close();
            }
            catch
            {
                MessageBox.Show("Подключение уже закрыто.");
            }
        }
    }
}
