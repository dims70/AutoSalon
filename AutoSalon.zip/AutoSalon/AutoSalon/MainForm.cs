﻿using System.Data.SqlClient;
using System.Windows.Forms;

namespace AutoSalon
{   /// <summary>
    /// Главная форма.Авторизация
    /// </summary>
    public partial class MainForm : Form
    {
        #region Обьявления
        public SignedUser send;
        Connection conn = new Connection();
        #endregion
        //Инициализация формы
        public MainForm()
        {   
            InitializeComponent();
            conn.ConnectionOpen();

        }
        //Кнопка авторизации
        private void btnAuth_Click(object sender, System.EventArgs e)
        {
            string query = $"select * from Авторизация where Логин='{LoginBox.Text}' and Пароль='{PassBox.Text}'";
            var command = new SqlCommand(query, conn.SqlConnection);
            var id = command.ExecuteScalar();
            if (id!=null)
            {   
                string queryLogin = $"select Логин from Авторизация where idМенеджера='{id}'";
                command.CommandText=queryLogin;
                var login = command.ExecuteScalar();
                send = new SignedUser((int)id, login+"");
                Hide();
                var IF = new InterfaceForm(this);
                IF.Show();
            }
            else MessageBox.Show("Логин и/или пароль неверны!");
        }
        //Кнопка перехода в админ панель
        private void btnAdmin_Click(object sender, System.EventArgs e)
        {
            Hide();
            var adm = new AdminPanelAuth(this);
            adm.Show();
        }
    }
}
