﻿using System;
using System.Collections.ObjectModel;
namespace AutoSalon
{   /// <summary>
    /// Класс автомобиля
    /// </summary>
    public class AutoClass
    {
        public string _stamp { get; set; }
        public string _model { get; set; }
        public string _category { get; set; }
        public string _typeBuild { get; set; }
        public string _typeBody { get; set; }
        public string _color { get; set; }
        public string _createYear { get; set; }
        public string _complect { get; set; }
        public decimal _cost { get; set; }
        public static ObservableCollection<AutoClass> AutoCollection { get; set; } = new ObservableCollection<AutoClass>();
        /// <summary>
        /// Конструктор автомобиля
        /// </summary>
        /// <param name="stamp">Марка</param>
        /// <param name="model">Модель</param>
        /// <param name="category">Класс</param>
        /// <param name="typeBuild">Тип сборки</param>
        /// <param name="typeBody">Тип кузова</param>
        /// <param name="color">Цвет</param>
        /// <param name="createYear">Год производства</param>
        /// <param name="complect">Комплектация</param>
        /// <param name="cost">Стоимость</param>
        public AutoClass(string stamp, string model, string category, string typeBuild, string typeBody, string color, string createYear, string complect, decimal cost)
        {
            _stamp = stamp;
            _model = model;
            _category = category;
            _typeBuild = typeBuild;
            _typeBody = typeBody;
            _color = color;
            _createYear = createYear;
            _complect = complect;
            _cost = cost;
        }
        //Пустой конструктор
        public AutoClass()
        {

        }
        //Переопределение ToString
        public override string ToString()
        {
            return _stamp+" "+_model;
        }
    }
}
