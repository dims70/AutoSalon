﻿using System;

namespace AutoSalon
{   /// <summary>
    /// Распределения задач основным работам системы
    /// </summary>
    interface IServices
    {   /// <summary>
        /// Создание заказа
        /// </summary>
        void CreateOrder(
            int idManager,
            string numcontact,
            string FIO_Client,
            string Adr_Client,
            string PhoneNumber, 
            string Passport,
            int idCar,
            int idDist,
            decimal endCost);
        /// <summary>
        /// Создание поставки
        /// </summary>
        void CreateSupply(
            DateTime date, 
            int CodeAuto,
            int number, 
            decimal FinSumm,
            int idSupplier);
        /// <summary>
        /// Добавление поставщика
        /// </summary>
        void AddSupplier(
            string Name,
            string Adress,
            string PhoneNum,
            string NumberContract);
        /// <summary>
        /// Добавление перегонщика
        /// </summary>
        void AddDist(
            string Name,
            string PhoneNumm, 
            string TypeDist,
            decimal cost);
        /// <summary>
        /// Добавление автомобиля в базу
        /// </summary>
        void AddAuto(
            string stamp,
            string model,
            string type,
            string typeBuild,
            string typeBody,
            string color,
            string yearBorn,
            string complect,
            decimal cost);
        /// <summary>
        /// Добавление договора на поставщика
        /// </summary>
        void AddContract(string numContract, DateTime dCreate, DateTime dExpires);
    }
}
