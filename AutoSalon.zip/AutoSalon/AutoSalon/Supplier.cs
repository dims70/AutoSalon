﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoSalon
{
   public class Supplier
    {
        public string _name { get; set; }
        public string _phone { get; set; }
        public string _adress { get; set; }
        public int _numberDog { get; set; }
        public Supplier(string name, string phone, string adress, int numberDog)
        {
            _name = name;
            _phone = phone;
            _adress = adress;
            _numberDog = numberDog;
        }
    }
}
