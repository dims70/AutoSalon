﻿namespace AutoSalon
{
    partial class AdminPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataManager = new System.Windows.Forms.DataGridView();
            this.dataAuthMenager = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSaveData = new System.Windows.Forms.Button();
            this.btnDeleteManager = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnAuthManagerDel = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataAuthMenager)).BeginInit();
            this.SuspendLayout();
            // 
            // dataManager
            // 
            this.dataManager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataManager.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.btnDeleteManager});
            this.dataManager.Location = new System.Drawing.Point(12, 32);
            this.dataManager.Name = "dataManager";
            this.dataManager.Size = new System.Drawing.Size(395, 403);
            this.dataManager.TabIndex = 0;
            this.dataManager.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataManager_CellContentClick);
            // 
            // dataAuthMenager
            // 
            this.dataAuthMenager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataAuthMenager.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.btnAuthManagerDel});
            this.dataAuthMenager.Location = new System.Drawing.Point(413, 32);
            this.dataAuthMenager.Name = "dataAuthMenager";
            this.dataAuthMenager.Size = new System.Drawing.Size(400, 403);
            this.dataAuthMenager.TabIndex = 1;
            this.dataAuthMenager.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataAuthMenager_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(166, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Данные менеджера";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(505, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(256, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Данные для авторизации менеджера";
            // 
            // btnSaveData
            // 
            this.btnSaveData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnSaveData.Location = new System.Drawing.Point(12, 441);
            this.btnSaveData.Name = "btnSaveData";
            this.btnSaveData.Size = new System.Drawing.Size(801, 40);
            this.btnSaveData.TabIndex = 4;
            this.btnSaveData.Text = "Сохранить";
            this.btnSaveData.UseVisualStyleBackColor = true;
            this.btnSaveData.Click += new System.EventHandler(this.btnSaveData_Click);
            // 
            // btnDeleteManager
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.NullValue = "Удалить";
            this.btnDeleteManager.DefaultCellStyle = dataGridViewCellStyle3;
            this.btnDeleteManager.HeaderText = "";
            this.btnDeleteManager.Name = "btnDeleteManager";
            this.btnDeleteManager.Text = "Удалить";
            // 
            // btnAuthManagerDel
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.NullValue = "Удалить";
            this.btnAuthManagerDel.DefaultCellStyle = dataGridViewCellStyle4;
            this.btnAuthManagerDel.HeaderText = "";
            this.btnAuthManagerDel.Name = "btnAuthManagerDel";
            // 
            // AdminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 493);
            this.Controls.Add(this.btnSaveData);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataAuthMenager);
            this.Controls.Add(this.dataManager);
            this.Name = "AdminPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminPanel";
            ((System.ComponentModel.ISupportInitialize)(this.dataManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataAuthMenager)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataManager;
        private System.Windows.Forms.DataGridView dataAuthMenager;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSaveData;
        private System.Windows.Forms.DataGridViewButtonColumn btnDeleteManager;
        private System.Windows.Forms.DataGridViewButtonColumn btnAuthManagerDel;
    }
}